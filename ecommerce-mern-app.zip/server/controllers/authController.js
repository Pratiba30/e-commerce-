const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const User = require("../models/User");

exports.register = async (req, res) => {
  const { email, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);
  const newUser = await User.create({ email, password: hashedPassword });
  res.status(201).json({ token: jwt.sign({ id: newUser._id }, process.env.JWT_SECRET) });
};

exports.login = async (req, res) => {
  const user = await User.findOne({ email: req.body.email });
  if (user && await bcrypt.compare(req.body.password, user.password)) {
    res.json({ token: jwt.sign({ id: user._id }, process.env.JWT_SECRET) });
  } else {
    res.status(401).json({ message: "Invalid credentials" });
  }
};