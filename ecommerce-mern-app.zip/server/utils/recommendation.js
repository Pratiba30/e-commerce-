const recommendProducts = (userHistory, allProducts) => {
  return allProducts.filter(product => userHistory.includes(product.category));
};

module.exports = recommendProducts;