# 🛒 E-Commerce Platform (MERN Stack)

A modern e-commerce web application with secure login, product filtering, Stripe checkout, admin dashboard, and AI product recommendations.

## 🚀 Features
- User authentication (JWT)
- Product filtering & search
- Cart & checkout
- Stripe payment integration
- Admin dashboard
- AI-powered product recommendations

## 🔧 Tech Stack
- MongoDB | Express.js | React.js | Node.js
- Stripe API
- TensorFlow.js (for recommendations)

## 📦 Installation
```bash
git clone https://github.com/yourusername/ecommerce-mern-app.git
cd ecommerce-mern-app
npm install && cd client && npm install
```

## 🏃 Run Project
```bash
# In root
npm run dev
```

## 🌐 Live Demo
Coming soon on [Vercel/Netlify + Render/Heroku]