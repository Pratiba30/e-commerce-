import React, { useEffect, useState } from 'react';
import axios from 'axios';

function ProductList() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    axios.get('/api/products').then(res => setProducts(res.data));
  }, []);

  return (
    <div className="grid">
      {products.map(prod => (
        <div key={prod._id} className="card">
          <h3>{prod.name}</h3>
          <p>${prod.price}</p>
        </div>
      ))}
    </div>
  );
}

export default ProductList;